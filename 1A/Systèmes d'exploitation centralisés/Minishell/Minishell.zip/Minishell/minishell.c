/* Auteur : Ayoub Bouchama
 * Groupe : F
 * Minishell
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "readcmd.h"
#include "job.h"
#include <signal.h>
#include "display.h"

#define UID_START 1000

/* Le répertoire courant */
char *RepertoireCourant;
/* La ligne de commande saisie */
struct cmdline *cmd;
/* La table des jobs */
jobsTable *jt;
/* Compeur pour les UIDs */
int COMPTEUR_UID = 0;
/* Le pid du processus fils */
pid_t pid;
/* Statut du processus */
int status;
/* Handler du signal CTRL+Z. */
struct sigaction actionCTRLZ;
/* Handler du signal CTRL+C. */
struct sigaction actionCTRLC;


/* Fonction qui lit une ligne de commande. */
void lirecmd() {
    do {
        RepertoireCourant = malloc(100 * sizeof(char));
        strcpy(RepertoireCourant, getcwd(NULL, 0));
        printf("\033[31m\033[1m\n%s\033[0m", RepertoireCourant);
	printf("\033[1m> \033[0m");
        fflush(stdout);
        cmd = readcmd();
    } while (cmd->seq[0] == NULL);
}

/* Fonction cd qui change le répertoire courant. */
void cd(char *path) {
    if (path == NULL || strcmp(path, "~") == 0) {
        chdir(getenv("HOME"));
    } else {
        chdir(path);
    }
}

/* Fonction qui retourne la commande saisie. */
char *getCmd(struct cmdline *cmd) {
    char *cmdLine = malloc(100 * sizeof(char));
    cmdLine[0] = '\0'; // initialiser la chaîne de caractères à une chaîne vide
    int i = 0;
    while (cmd->seq[0][i] != NULL) {
        strcat(cmdLine, cmd->seq[0][i]);
        strcat(cmdLine, " ");
        i++;
    }
    return cmdLine;
}

/* Fonction qui retourne l'état du processus. */
int etat_processus(pid_t pid) {
    int ret = kill(pid, 0);
    if (ret == 0) {
        // Le processus existe, on envoie un signal SIGCONT pour tester son état
        ret = kill(pid, SIGCONT);
        if (ret == 0) {
            // Le signal a été envoyé avec succès, le processus est actif
            return 1;
        }
    }
    return 0;
}

/* Mettre à jour l'état des jobs. */
void mise_a_jour(jobsTable *jt) {
    Cellule *c = jt->tete;
    while (c != NULL) {
        if (etat_processus(c->job->PID) == 0) {
            c->job->STAT = SUSPENDU;
        } else {
            c->job->STAT = ACTIF;
        }
        c = c->suivant;
    }
}

/* Handler du signal CTRL+Z. */
void handler_SIGTSTP(int sig) {
    kill(pid, SIGSTOP);
    mise_a_jour(jt);
}

/* Handler du signal CTRL+C. */
void handler_SIGINT(int sig) {
    kill(pid, SIGKILL);
    supprimer_job(jt, pid);
    mise_a_jour(jt);
}

/* Suspendre le minishell et lui seul. */
void susp() {
    printf("Minishell en cours de suspension...\n");
    sleep(2);
    kill(getpid(), SIGSTOP);
}

/* Gestion des redirections. */
void gestionRedirections(char* nomFichier, int mode) {

    /* mode = 0 : redirection de l'entrée standard
     * mode = 1 : redirection de la sortie standard
     */

    int fd;
    // Ouvrir le fichier en ecriture et création s'il n'existe pas.
    if (mode == 0) {
        fd = open(nomFichier, O_RDWR | O_CREAT | O_TRUNC, 0640);
        if (fd == -1) {
            perror("Erreur lors de l'ouverture du fichier");
            exit(1);
        }
    // Ouvrir le fichier en lecture.
    } else if (mode == 1) {
        fd = open(nomFichier, O_RDONLY);
        if (fd == -1) {
            perror("Erreur lors de l'ouverture du fichier");
            exit(1);
        }
    }
    // Redirection de l'entrée standard.
    if (dup2(fd, mode) == -1) {
        perror("Erreur lors de la redirection");
        exit(1);
    }
    // Fermer le fichier.
    if (close(fd) == -1) {
        perror("Erreur lors de la fermeture du fichier");
        exit(1);
    }
}

/* Gestion des commandes internes. */
bool gestionCommandesInternes() {
    bool cmdInterne = false;
    if (strcmp(cmd->seq[0][0], "exit") == 0) {
        cmdInterne = true;
        exit(0);
    } else if (strcmp(cmd->seq[0][0], "cd") == 0) {
        cd(cmd->seq[0][1]);
        cmdInterne = true;
    } else if (strcmp(cmd->seq[0][0], "susp") == 0) {
        susp();
        cmdInterne = true;
    } else if (strcmp(cmd->seq[0][0], "lj") == 0) {
        afficher_jobs(jt);
        cmdInterne = true;
    } else if (strcmp(cmd->seq[0][0], "sj") == 0) {
        int uid_sj = atoi(cmd->seq[0][1]);
        suspendre_job(jt, uid_sj);
        cmdInterne = true;
    } else if (strcmp(cmd->seq[0][0], "bg") == 0) {
        int uid_bg = atoi(cmd->seq[0][1]);
        reprendre_job_en_arriere_plan(jt, uid_bg);
        cmdInterne = true;
    } else if (strcmp(cmd->seq[0][0], "fg") == 0) {
        int uid_fg = atoi(cmd->seq[0][1]);
        reprendre_job_en_avant_plan(jt, uid_fg);
        cmdInterne = true;
    }
    return cmdInterne;
}

/* Initialiser le handler des signaux CTRL+Z et CTRL+C. */
void InitialiserHandler() {
    // Initialisation du handler du signal CTRL+Z.
    actionCTRLZ.sa_handler = handler_SIGTSTP;
    sigemptyset(&actionCTRLZ.sa_mask);
    actionCTRLZ.sa_flags = 0;
    sigaction(SIGTSTP, &actionCTRLZ, NULL);

    // Initialisation du handler du signal CTRL+C.
    actionCTRLC.sa_handler = handler_SIGINT;
    sigemptyset(&actionCTRLC.sa_mask);
    actionCTRLC.sa_flags = 0;
    sigaction(SIGINT, &actionCTRLC, NULL);
}

/* Fonction principale. */
int main() {
    // Initialisation de la table des jobs.
    jobsTable *jt = malloc(sizeof(jobsTable));
    initialiser_jobTable(jt);

    // Initialisation du handler du signal CTRL+Z.
    InitialiserHandler();

    // Affichage du logo du shell.  
    display_logo();

    while (1) {
        // Lecture de la commande.
        lirecmd();

        // Gestion des commandes internes et externes.
        if(!gestionCommandesInternes()) {
            // Exécuter la commande.
            pid = fork();
            if (pid == -1) {
                // Erreur lors de la création du processus fils.
                perror("fork");
                exit(1);
            } else if (pid == 0) {
                // Processus fils.

                // Débloquer les signaux SIGTSTP et SIGINT pour le processus fils.
                sigset_t sigset;
                sigemptyset(&sigset);
                sigaddset(&sigset, SIGTSTP);
                sigaddset(&sigset, SIGINT);
                sigprocmask(SIG_UNBLOCK, &sigset, NULL);

                // Gestion des redirections.
                if (cmd->seq[1] == NULL) {
                    if (cmd->out != NULL) {
                        gestionRedirections(cmd->out, 0);
                    }
                    if (cmd->in != NULL) {
                        gestionRedirections(cmd->in, 1);
                    }
                }
                // Processus fils pour l'exécution en avant-plan.
                ajouter_job(jt, COMPTEUR_UID + UID_START, getpid(), getppid(), SUSPENDU, getCmd(cmd));
                COMPTEUR_UID++;
                execvp(cmd->seq[0][0], cmd->seq[0]);
                // Erreur lors de l'exécution de la commande.
                perror("execvp");
                exit(1);
            } else {
                // Processus père.
                if (cmd->backgrounded == NULL) {
                    // Processus père pour l'exécution en avant-plan.
                    ajouter_job(jt, COMPTEUR_UID + UID_START, pid, getpid(), ACTIF, getCmd(cmd));
                    COMPTEUR_UID++;
                    waitpid(pid, &status, 0);
                } else {
                    // Processus père pour l'exécution en arrière-plan.
                    ajouter_job(jt, COMPTEUR_UID + UID_START, pid, getpid(), ACTIF, getCmd(cmd));
                    COMPTEUR_UID++;
                }
                if (WIFEXITED(status) || WIFSIGNALED(status)) {
                    // Le processus fils s'est terminé normalement ou à cause d'un signal.
                    supprimer_job(jt, pid);
                }
            }
            // Mise à jour de la table des jobs après l'exécution de la commande.
            mise_a_jour(jt);
        }
    }
    return EXIT_SUCCESS;
}
