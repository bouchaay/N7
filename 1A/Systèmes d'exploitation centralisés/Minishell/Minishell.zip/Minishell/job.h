#ifndef __JOB_H__
#define __JOB_H__

#include "readcmd.h"

/* Définition des constantes */
#define MAX_JOBS 100
#define MAX_ARGS 100

/* Je prends dans ma solution la table des jobs comme une file.
 * La tete de la file est le premier job ajouté et la queue est le dernier job ajouté.
 * La table contient un compteur pour les UIDs.
 * Le compteur est incrémenté à chaque fois qu'on ajoute un job.
 * Un job est défini par son UID, son PID, son PPID, son statut et sa commande.
 */

/* Définition du type statut */
typedef enum {ACTIF, SUSPENDU} statut;

/* Définition du type job */
typedef struct job {
    int UID;
    pid_t PID;
    pid_t PPID;
    statut STAT;
    char cmd[MAX_ARGS];
} job;

/* Définition du type Cellule */
typedef struct Cellule {
    job *job;
    struct Cellule *suivant;
} Cellule;

/* Définition du type jobsTable */
typedef struct jobsTable {
    Cellule *tete;
    Cellule *queue;
} jobsTable;

/* Initialisation de la table des jobs.
 * @param jt : la table des jobs à initialiser.
 */
void initialiser_jobTable(jobsTable *jt);

/* Ajout d'un job dans la table des jobs.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à ajouter.
 * @param pid : le PID du job à ajouter.
 * @param ppid : le PPID du job à ajouter.
 * @param stat : le statut du job à ajouter.
 * @param cmd : la commande du job à ajouter.
 */
void ajouter_job(jobsTable *jt, int uid, pid_t pid, pid_t ppid, statut stat, char cmd[MAX_ARGS]);

/* Suppression d'un job de la table des jobs.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à supprimer.
 */
void supprimer_job(jobsTable *jt, int uid);

/* Affichage d'un job de la table des jobs.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à afficher.
 */
void afficher_job(jobsTable *jt, int uid);

/* Affichage de la table des jobs.
 * @param jt : la table des jobs.
 */
void afficher_jobs(jobsTable *jt);

/* Suspension d'un job de la table des jobs.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à suspendre.
 */
void suspendre_job(jobsTable *jt, int uid);

/* Reprendre un job de la table des jobs.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à reprendre.
 */
void reprendre_job(jobsTable *jt, int uid);

/* Reprendre un job de la table des jobs en arrière plan.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à reprendre.
 */
void reprendre_job_en_arriere_plan(jobsTable *jt, int uid);

/* Reprendre un job de la table des jobs en avant plan.
 * @param jt : la table des jobs.
 * @param uid : l'UID du job à reprendre.
 */
void reprendre_job_en_avant_plan(jobsTable *jt, int uid);

/* Vider la table des jobs.
 * @param jt : la table des jobs.
 */
void vider_jobTable(jobsTable *jt);

#endif /* __JOB_H__ */
