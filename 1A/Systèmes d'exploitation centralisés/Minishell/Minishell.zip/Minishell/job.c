/* Auteur : Ayoub Bouchama
 * Groupe : F
 * Manipuler les jobs
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "readcmd.h"
#include "job.h"


void initialiser_jobTable(jobsTable *jt) {
    jt->tete = NULL;
    jt->queue = NULL;
}

void ajouter_job(jobsTable *jt, int uid, pid_t pid, pid_t ppid, statut stat, char cmd[MAX_ARGS]) {
    Cellule *c = malloc(sizeof(Cellule));
    c->job = malloc(sizeof(job));
    c->job->UID = uid;
    c->job->PID = pid;
    c->job->PPID = ppid;
    c->job->STAT = stat;
    strcpy(c->job->cmd, cmd);
    c->suivant = NULL;

    if (jt->queue == NULL) {
        jt->tete = c;
        jt->queue = c;
    } else {
        jt->queue->suivant = c;
        jt->queue = c;
    }
}

void supprimer_job(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;
    Cellule *precedent = NULL;

    while (c != NULL && c->job->UID != uid) {
        precedent = c;
        c = c->suivant;
    }

    if (c != NULL) {
        if (precedent == NULL) {
            jt->tete = c->suivant;
        } else {
            precedent->suivant = c->suivant;
        }
        if (c == jt->queue) {
            jt->queue = precedent;
        }
        free(c->job);
        free(c);
    }
}

void afficher_job(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;

    while (c != NULL && c->job->UID != uid) {
        c = c->suivant;
    }

    if (c != NULL) {
        printf("UID     PID     PPID    STAT    CMD\n");
        printf("[%d]    %d      %d      %d      %s\n", c->job->UID, c->job->PID, c->job->PPID, c->job->STAT, c->job->cmd);
    }
}

void afficher_jobs(jobsTable *jt) {
    Cellule *c = jt->tete;
    printf(" UID       PID       PPID     STAT   CMD\n");
    while (c != NULL) {
        printf("[%d]    %d      %d      %d      %s\n", c->job->UID, c->job->PID, c->job->PPID, c->job->STAT, c->job->cmd);
        c = c->suivant;
    }
}

void suspendre_job(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;

    while (c != NULL && c->job->UID != uid) {
        c = c->suivant;
    }

    if (c != NULL) {
        c->job->STAT = SUSPENDU;
        kill(c->job->PID, SIGSTOP);
    }
}

void reprendre_job(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;
    while (c != NULL) {
        if (c->job->UID == uid) {
            c->job->STAT = ACTIF;
            break;
        }
        c = c->suivant;
    }
}

void reprendre_job_en_arriere_plan(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;
    while (c != NULL) {
        if (c->job->UID == uid) {
            c->job->STAT = ACTIF;
            kill(c->job->PID, SIGCONT);
            break;
        }
        c = c->suivant;
    }
}

void reprendre_job_en_avant_plan(jobsTable *jt, int uid) {
    Cellule *c = jt->tete;
    while (c != NULL) {
        if (c->job->UID == uid) {
            c->job->STAT = ACTIF;
            kill(c->job->PID, SIGCONT);
            waitpid(c->job->PID, 0, 0);
            break;
        }
        c = c->suivant;
    }
}

void vider_jobTable(jobsTable *jt) {
    Cellule *c = jt->tete;
    Cellule *suivant = NULL;

    while (c != NULL) {
        suivant = c->suivant;
        free(c->job);
        free(c);
        c = suivant;
    }
    jt->tete = NULL;
    jt->queue = NULL;
}

