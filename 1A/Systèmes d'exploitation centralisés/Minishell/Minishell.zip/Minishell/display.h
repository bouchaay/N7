// afficher un logo 'AYOUB' dans l'affichage du shell

#ifndef DISPLAY_H
#define DISPLAY_H

/* Afficher le logo 'AYOUB' */
void display_logo();

#endif
