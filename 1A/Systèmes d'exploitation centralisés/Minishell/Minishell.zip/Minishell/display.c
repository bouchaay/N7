/* Auteur : Ayoub Bouchama
 * Groupe : F
 * Logo du shell
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void display_logo() {
    clear_screen();
    printf("\n");
    printf("  ________   __    __   _________    __     __    _________ ");
    printf(" |  ____  | |  |  |  | |   ___   |  |  |   |  |  |   ___   |");
    printf(" |  |__|  | |  |__|  | |  |   |  |  |  |   |  |  |  |___|  |");
    printf(" |  ____  | |__    __| |  |   |  |  |  |   |  |  |  _______|");
    printf(" | |    | |    |  |    |  |   |  |  |  |   |  |  |   ___   |");
    printf(" | |    | |    |  |    |  |___|  |  |  |___|  |  |  |___|  |");
    printf(" |_|    |_|    |__|    |_________|  |_________|  |_________|");
    printf("\n");
    printf("\n");
}
    